<?php 
/**
 * This is where you can register custom taxonomies.
 */

function register_taxonomies() {
    //shhhh
}