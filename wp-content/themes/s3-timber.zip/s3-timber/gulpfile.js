var gulp = require('gulp');
var fs = require('fs');
var less = require('gulp-less');
var babel = require('gulp-babel');
var concat = require('gulp-concat');
var terser = require('gulp-terser');
var rename = require('gulp-rename');
var forEach = require('gulp-foreach');
var csso = require('gulp-csso');

const path = require('path');
const { log } = require('console');
const { exit } = require('process');

dir = process.env.INIT_CWD;
let working_dir = process.env.INIT_CWD+'/';
slug = working_dir.split('/').at(-2).replace('nmc_','');
console.log('Project slug: '+slug);
console.log('Calling dir: '+dir);

let theme_dir = dir+'/';

var paths = {
    styles: {
        // primary styles
        src: theme_dir+'src/less/all.less',
        dest: theme_dir+'css/'
    },
    editorStyles: {
        src: theme_dir+'src/less/gutenberg-editor.less',
        dest: theme_dir+'css/'
    },
    watchStyles: {
        src: [
            theme_dir+'src/less/**/*.less',
            theme_dir+'blocks/**/*.less'
        ]
    },
    blockStyles: {
        // block styles
        src: [
            theme_dir+'src/less/gutenberg-editor.less',
            theme_dir+'blocks/**/style.less'
        ]// dest will be written at compile time
    },
    scripts: {
        // primary scripts
        src: [
            theme_dir+'src/scripts/libs/**/*.js',
            theme_dir+'src/scripts/*.js'
        ],
        dest: theme_dir+'scripts/'
    },
    scriptsBandwidth: {
        // primary scripts
        src: [
            theme_dir+'src/scripts/legacy/bandwidth.js',
        ],
        dest: theme_dir+'scripts/'
    },
    scriptsCalculator: {
        // primary scripts
        src: [
            theme_dir+'src/scripts/legacy/calculator.js',
        ],
        dest: theme_dir+'scripts/'
    },
    blockScripts: {
        src: theme_dir+'blocks/**/script.js'// dest will be written at compile time
    },
    twig: {
        src: [
            theme_dir+'templates/**/*.twig',
            theme_dir+'blocks/**/*.twig'
        ]
    }
};

/*
 * Define our tasks using plain functions
 */
function styles() {
    return gulp.src(paths.styles.src)
        .pipe(less({
            'math': 'always',
            'paths': [theme_dir+'src/less']
        }))
        .pipe(csso())
        // pass in options to the stream
        .pipe(rename({
            basename: 'all',
            suffix: '.min'
        }))
        .pipe(gulp.dest(paths.styles.dest));
}

function editorStyles() {
    return gulp.src(paths.editorStyles.src, {allowEmpty: true})
        .pipe(less({
            'math': 'always',
            'paths': [theme_dir+'src/less']
        }))
        .pipe(csso())
        // pass in options to the stream
        .pipe(rename({
            basename: 'gutenberg-editor',
            suffix: '.min'
        }))
        .pipe(gulp.dest(paths.editorStyles.dest));
}

function blockStyles() {
    return gulp.src(paths.blockStyles.src, {allowEmpty: true})
    .pipe(less({
        'math': 'always',
        'paths': [theme_dir+'src/less']
    }))
    .pipe(csso())
    // legacy block styles
    .pipe(forEach( (stream, file) => {
        let dir = path.parse(file.path).dir;
        let blockSlug = dir.split('/').at(-1);
        return stream
        .pipe(
            rename({
                basename: '../'+blockSlug,
                suffix: '.min'
            })
        )
        .pipe(
            gulp.dest(function(file) {
                return theme_dir + 'css/blocks/';
            })
        )
        .pipe(
            rename({
                basename: 'style',
                suffix: '.min'
            })
        )
        .pipe(
            gulp.dest(function(file) {
                return theme_dir + '/blocks/' + blockSlug;
            })
        );
    }))

    .pipe(concat('all.min.css'))
    .pipe(gulp.dest(theme_dir + '/css/blocks'))
}
 
function scripts() {
    return gulp.src(paths.scripts.src)
    .pipe(concat('all.min.js'))
    .pipe(babel())
    .pipe(terser({
        'format': {
            'comments': false
        }
    }))
    .pipe(gulp.dest(paths.scripts.dest));
}

function scriptsBandwidth() {
    return gulp.src(paths.scriptsBandwidth.src)
    .pipe(concat('bandwidth.min.js'))
    .pipe(babel())
    .pipe(terser({
        'format': {
            'comments': false
        }
    }))
    .pipe(gulp.dest(paths.scriptsBandwidth.dest));
}

function scriptsCalculator() {
    return gulp.src(paths.scriptsCalculator.src)
    .pipe(concat('calculator.min.js'))
    .pipe(babel())
    .pipe(terser({
        'format': {
            'comments': false
        }
    }))
    .pipe(gulp.dest(paths.scriptsCalculator.dest));
}


function blockScripts() {
    return gulp.src(paths.blockScripts.src)
    .pipe(babel())
    .pipe(terser())
    .pipe(forEach( (stream, file) => {
        let fileName = path.basename(file.path, path.extname(file.path));
        return stream
        .pipe(rename({
            basename: fileName,
            suffix: '.min'
        }))
        .pipe(
            gulp.dest(theme_dir + '/blocks/')
        );
    }))
}
 
var watch = function(){
    build();
    gulp.watch(paths.watchStyles.src, {usePolling:true}, gulp.series(styles, blockStyles, buildVersionfile));
    gulp.watch(paths.scripts.src,{usePolling:true}, gulp.series(scripts, buildVersionfile));
    gulp.watch(paths.scriptsBandwidth.src,{usePolling:true}, gulp.series(scriptsBandwidth));
    gulp.watch(paths.scriptsCalculator.src,{usePolling:true}, gulp.series(scriptsCalculator));
    gulp.watch(paths.blockScripts.src,{usePolling:true}, gulp.series(blockScripts));
    gulp.watch(paths.twig.src,{usePolling:true}, gulp.series(buildVersionfile));
}

/**
 * Build Version Filels
 */
function buildVersionfile(cb) {
    var ts = Math.floor(new Date().getTime() / 1000);
    fs.writeFile(theme_dir+'templates/_version.num', ts.toString(), {}, function() {});
    cb();
}
 
/*
 * Specify if tasks run in series or parallel using `gulp.series` and `gulp.parallel`
 */
var build = gulp.series(gulp.parallel(
    styles, 
    blockStyles,
    editorStyles,
    scripts,
    scriptsBandwidth,
    scriptsCalculator,
    blockScripts, 
    buildVersionfile
));
 
/*
 * You can use CommonJS `exports` module notation to declare tasks
 */
exports.styles = styles;
exports.blockStyles = blockStyles;
exports.editorStyles = editorStyles;
exports.scripts = scripts;
exports.scriptsBandwidth = scriptsBandwidth;
exports.scriptsCalculator = scriptsCalculator;
exports.blockScripts = blockScripts;
exports.watch = watch;
exports.build = build;
/*
 * Define default task that can be called by just running `gulp` from cli
 */
exports.default = exports.build;
