<?php
/**
 * Template Name: Home Page Template
 * Description: Page template for the home page.
 */

$context         = Timber::context();
$timber_post     = Timber::get_post();
$context['post'] = $timber_post;